# Constants for Hindu Panchanga (Multi-language)

LANGUAGES = ["EN", "KN", "SA"]

SAMVATSARAS = {
    "EN": [
        "Prabhava", "Vibhava", "Shukla", "Pramodoota", "Prajotpatti", "Angirasa", "Shrimukha", "Bhava", "Yuva", "Dhatu",
        "Ishvara", "Bahudhanya", "Pramathi", "Vikrama", "Vrisha", "Chitrabhanu", "Swarabhanu", "Tarana", "Parthiva", "Vyaya",
        "Sarvajitu", "Sarvadhari", "Virodhi", "Vikriti", "Khara", "Nandana", "Vijaya", "Jaya", "Manmatha", "Durmukha",
        "Hevilambi", "Vilambi", "Vikari", "Sharvari", "Plava", "Shubhakritu", "Shobhakritu", "Krodhi", "Vishvavasu", "Paridhavi",
        "Pramadicha", "Ananda", "Rakshasa", "Anala", "Pingala", "Kalayukti", "Siddharthi", "Raudri", "Durmati", "Dundubhi",
        "Rudhirodgari", "Raktakshi", "Krodhana", "Akshaya", "Nala", "Pingala", "Kalayukti", "Siddharthi", "Raudri", "Durmati"
    ],
    "KN": [
        "ಪ್ರಭವ", "ವಿಭವ", "ಶುಕ್ಲ", "ಪ್ರಮೋದೂತ", "ಪ್ರಜೋತ್ಪತ್ತಿ", "ಆಂಗಿರಸ", "ಶ್ರೀಮುಖ", "ಭವ", "ಯುವ", "ಧಾತು",
        "ಈಶ್ವರ", "ಬಹುಧಾನ್ಯ", "ಪ್ರಮಾಥಿ", "ವಿಕ್ರಮ", "ವೃಷ", "ಚಿತ್ರಭಾನು", "ಸ್ವಭಾನು", "ತಾರಣ", "ಪಾರ್ಥಿವ", "ವ್ಯಯ",
        "ಸರ್ವಜಿತ್ತು", "ಸರ್ವಧಾರಿ", "ವಿರೋಧಿ", "ವಿಕೃತಿ", "ಖರ", "ನಂದನ", "ವಿಜಯ", "ಜಯ", "ಮನ್ಮಥ", "ದುರ್ಮುಖಿ",
        "ಹೇವಿಳಂಬಿ", "ವಿಳಂಬಿ", "ವಿಕಾರಿ", "ಶಾರ್ವರಿ", "ಪ್ಲವ", "ಶುಭಕೃತು", "ಶೋಭಕೃತು", "ಕ್ರೋಧಿ", "ವಿಶ್ವಾವಸು", "ಪರಿದ್ಧಾವಿ",
        "ಪ್ರಮಾದೀಚ", "ಆನಂದ", "ರಾಕ್ಷಸ", "ನಳ", "ಪಿಂಗಳ", "ಕಾಳಯುಕ್ತಿ", "ಸಿದ್ಧಾರ್ಥಿ", "ರೌದ್ರಿ", "ದುರ್ಮತಿ", "ದುಂದುಭಿ",
        "ರುಧಿರೋದ್ಗಾರಿ", "ರಕ್ತಾಕ್ಷಿ", "ಕ್ರೋಧನ", "ಅಕ್ಷಯ", "ನಳ", "ಪಿಂಗಳ", "ಕಾಳಯುಕ್ತಿ", "ಸಿದ್ಧಾರ್ಥಿ", "ರೌದ್ರಿ", "ದುರ್ಮತಿ"
    ],
    "SA": [
        "प्रभवः", "विभवः", "शुक्लः", "प्रमोदूतः", "प्रजोत्पत्तिः", "आंगिरसः", "श्रीमुखः", "भवः", "युवा", "धाता",
        "ईश्वरः", "बहुधान्यः", "प्रमाथी", "विक्रमः", "वृषः", "चित्रभानुः", "स्वभानुः", "तारणः", "पार्थिवः", "व्ययः",
        "सर्वजित्", "सर्वधारी", "विरोधी", "विकृतिः", "खरः", "नन्दनः", "विजयः", "जयः", "मन्मथः", "दुर्मुखः",
        "हेविलम्बी", "विलम्बी", "विकारी", "शार्वरी", "प्लवः", "शुभकृत्", "शोभकृत्", "क्रोधी", "विश्वावसुः", "परिधावी",
        "प्रमादी", "आनन्दः", "राक्षसः", "नलः", "पिङ्गलः", "कालयुक्तिः", "सिद्धार्थी", "रौद्री", "दुर्मतिः", "दुन्दुभिः",
        "रुधिरोद्गारी", "रक्ताक्षी", "क्रोधनः", "अक्षयः", "नलः", "पिङ्गलः", "कालयुक्तिः", "सिद्धार्थी", "रौद्री", "दुर्मतिः"
    ]
}

MASAS = {
    "EN": ["Chaitra", "Vaishakha", "Jyeshtha", "Ashadha", "Shravana", "Bhadrapada", "Ashvin", "Kartika", "Margashirsha", "Pausha", "Magha", "Phalguna"],
    "KN": ["ಚೈತ್ರ", "ವೈಶಾಖ", "ಜ್ಯೇಷ್ಠ", "ಆಷಾಢ", "ಶ್ರಾವಣ", "ಭಾದ್ರಪದ", "ಆಶ್ವಯುಜ", "ಕಾರ್ತಿಕ", "ಮಾರ್ಗಶಿರ", "ಪುಷ್ಯ", "ಮಾಘ", "ಫಾಲ್ಗುಣ"],
    "SA": ["चैत्रः", "वैशाखः", "ज्येष्ठः", "आषाढः", "श्रावणः", "भाद्रपदः", "आश्विनः", "कार्तिकः", "मार्गशीर्षः", "पौषः", "माघः", "फाल्गुनः"]
}

PAKSHAS = {
    "EN": ["Shukla", "Krishna"],
    "KN": ["ಶುಕ್ಲ", "ಕೃಷ್ಣ"],
    "SA": ["शुक्ल", "कृष्ण"]
}

TITHIS = {
    "EN": [
        "Prathama", "Dwitiya", "Tritiya", "Chaturthi", "Panchami", "Shashthi", "Saptami", "Ashtami", "Navami", "Dashami", "Ekadashi", "Dwadashi", "Trayodashi", "Chaturdashi", "Purnima",
        "Prathama", "Dwitiya", "Tritiya", "Chaturthi", "Panchami", "Shashthi", "Saptami", "Ashtami", "Navami", "Dashami", "Ekadashi", "Dwadashi", "Trayodashi", "Chaturdashi", "Amavasya"
    ],
    "KN": [
        "ಪ್ರಥಮಾ", "ದ್ವಿತೀಯಾ", "ತೃತೀಯಾ", "ಚತುರ್ಥೀ", "ಪಂಚಮೀ", "ಷಷ್ಠೀ", "ಸಪ್ತಮೀ", "ಅಷ್ಟಮೀ", "ನವಮೀ", "ದಶಮೀ", "ಏಕಾದಶೀ", "ದ್ವಾದಶೀ", "ತ್ರಯೋದಶೀ", "ಚತುರ್ದಶೀ", "ಪೂರ್ಣಿಮಾ",
        "ಪ್ರಥಮಾ", "ದ್ವಿತೀಯಾ", "ತೃತೀಯಾ", "ಚತುರ್ಥೀ", "ಪಂಚಮೀ", "ಷಷ್ಠೀ", "ಸಪ್ತಮೀ", "ಅಷ್ಟಮೀ", "ನವಮೀ", "ದಶಮೀ", "ಏಕಾದಶೀ", "ದ್ವಾದಶೀ", "ತ್ರಯೋದಶೀ", "ಚತುರ್ದಶೀ", "ಅಮಾವಾಸ್ಯಾ"
    ],
    "SA": [
        "प्रथमा", "द्वितीया", "तृतीया", "चतुर्थी", "पञ्चमी", "षष्ठी", "सप्तमी", "अष्टमी", "नवमी", "दशमी", "एकादशी", "द्वादशी", "त्रयोदशी", "चतुर्दशी", "पूर्णिमा",
        "प्रथमा", "द्वितीया", "तृतीया", "चतुर्थी", "पञ्चमी", "षष्ठी", "सप्तमी", "अष्टमी", "नवमी", "दशमी", "एकादशी", "द्वादशी", "त्रयोदशी", "चतुर्दशी", "अमावास्या"
    ]
}

NAKSHATRAS = {
    "EN": [
        "Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashirsha", "Ardra", "Punarvasu", "Pushya", "Ashlesha", "Magha", "Purva Phalguni", "Uttara Phalguni", "Hasta", "Chitra", "Swati", "Vishakha", "Anuradha", "Jyeshtha", "Mula", "Purva Ashadha", "Uttara Ashadha", "Shravana", "Dhanishta", "Shatabhisha", "Purva Bhadrapada", "Uttara Bhadrapada", "Revati"
    ],
    "KN": [
        "ಅಶ್ವಿನಿ", "ಭರಣಿ", "ಕೃತ್ತಿಕಾ", "ರೋಹಿಣಿ", "ಮೃಗಶಿರಾ", "ಆರಿದ್ರಾ", "ಪುನರ್ವಸು", "ಪುಷ್ಯ", "ಆಶ್ಲೇಷಾ", "ಮಘಾ", "ಪೂರ್ವ ಫಲ್ಗುಣಿ", "ಉತ್ತರ ಫಲ್ಗುಣಿ", "ಹಸ್ತ", "ಚಿತ್ರಾ", "ಸ್ವಾತಿ", "ವಿಶಾಖಾ", "ಅನುರಾಧಾ", "ಜ್ಯೇಷ್ಠಾ", "ಮೂಲಾ", "ಪೂರ್ವಾಷಾಢ", "ಉತ್ತರಾಷಾಢ", "ಶ್ರವಣ", "ಧನಿಷ್ಠಾ", "ಶತಭಿಷ", "ಪೂರ್ವ ಭಾದ್ರಪದ", "ಉತ್ತರ ಭಾದ್ರಪದ", "ರೇವತಿ"
    ],
    "SA": [
        "अश्विनी", "भरणी", "कृत्तिका", "रोहिणी", "मृगशीर्ष", "आर्द्रा", "पुनर्वसु", "पुष्य", "आश्लेषा", "मघा", "पूर्वाफाल्गुनी", "उत्तराफाल्गुनी", "हस्तः", "चित्रा", "स्वाती", "विशाखा", "अनुराधा", "ज्येष्ठा", "मूलम्", "पूर्वाषाढा", "उत्तराषाढा", "श्रवणः", "धनिष्ठा", "शतभिषा", "पूर्वभाद्रपदा", "उत्तरभाद्रपदा", "रेवती"
    ]
}

NAKSHATRA_STARS = [
    "Beta Arietis", "41 Arietis", "Alcyone", "Aldebaran", "Lambda Orionis", "Betelgeuse", "Pollux", "Delta Cancri", 
    "Alpha Hydrae", "Regulus", "Delta Leonis", "Denebola", "Delta Corvi", "Spica", "Arcturus", "Alpha Librae", 
    "Delta Scorpionis", "Antares", "Lambda Scorpionis", "Delta Sagittarii", "Sigma Sagittarii", "Altair", 
    "Beta Delphini", "Lambda Aquarii", "Alpha Pegasi", "Gama Pegasi", "Zeta Piscium"
]

YOGAS = {
    "EN": [
        "Vishkumbha", "Preeti", "Ayushman", "Saubhagya", "Shobhana", "Atiganda", "Sukarma", "Dhriti", "Shoola", "Ganda", "Vriddhi", "Dhruva", "Vyaghata", "Harshana", "Vajra", "Siddhi", "Vyatipata", "Variyan", "Parigha", "Shiva", "Siddha", "Sadhya", "Shubha", "Shukla", "Brahma", "Indra", "Vaidhriti"
    ],
    "KN": [
        "ವಿಷ್ಕುಂಭ", "ಪ್ರೀತಿ", "ಆಯುಷ್ಮಾನ್", "ಸೌಭಾಗ್ಯ", "ಶೋಭನ", "ಅತಿಗಂಡ", "ಸುಕರ್ಮ", "ಧೃತಿ", "ಶೂಲ", "ಗಂಡ", "ವೃದ್ಧಿ", "ಧ್ರುವ", "ವ್ಯಾಘಾತ", "ಹರ್ಷಣ", "ವಜ್ರ", "ಸಿದ್ಧಿ", "ವ್ಯತೀಪಾತ", "ವರೀಯಾನ್", "ಪರಿಘ", "ಶಿವ", "ಸಿದ್ಧ", "ಸಾಧ್ಯ", "ಶುಭ", "ಶುಕ್ಲ", "ಬ್ರಹ್ಮ", "ಇಂದ್ರ", "ವೈಧೃತಿ"
    ],
    "SA": [
        "विष्कुम्भः", "प्रीतिः", "आयुष्मान्", "सौभाग्यम्", "शोभनः", "अतिगण्डः", "सुकर्मा", "धृतिः", "शूलः", "गण्डः", "वृद्धिः", "ध्रुवः", "व्याघातः", "हर्षणः", "वज्रः", "सिद्धिः", "व्यतीपातः", "वरीयान्", "परिघः", "शिवः", "सिद्धः", "साध्यः", "शुभः", "शुक्लः", "ब्रह्म", "इन्द्रः", "वैधृतिः"
    ]
}

VARAS = {
    "EN": ["Ravivara", "Somavara", "Mangalavara", "Budhavara", "Guruvara", "Shukravara", "Shanivara"],
    "KN": ["ರವಿವಾರ", "ಸೋಮವಾರ", "ಮಂಗಳವಾರ", "ಬುಧವಾರ", "ಗುರುವಾರ", "ಶುಕ್ರವಾರ", "ಶನಿವಾರ"],
    "SA": ["रविवासरः", "सोमवासरः", "मङ्गलवासरः", "बुधवासरः", "गुरुवासरः", "शुक्रवासरः", "शनिवासरः"]
}

RASIS = {
    "EN": ["Mesha", "Vrishabha", "Mithuna", "Karka", "Simha", "Kanya", "Tula", "Vrishchika", "Dhanu", "Makara", "Kumbha", "Meena"],
    "KN": ["ಮೇಷ", "ವೃಷಭ", "ಮಿಥುನ", "ಕರ್ಕ", "ಸಿಂಹ", "ಕನ್ಯಾ", "ತುಲಾ", "ವೃಶ್ಚಿಕ", "ಧನು", "ಮಕರ", "ಕುಂಭ", "ಮೀನ"],
    "SA": ["मेषः", "वृषभः", "मिथुनः", "कर्कः", "सिंहः", "कन्या", "तुला", "वृश्चिकः", "धनुः", "मकरः", "कुम्भः", "मीनः"]
}

REPORT_LABELS = {
    "EN": {
        "title": "HINDU PANCHANGA REPORT",
        "input_dt": "Input Date/Time",
        "location": "Location",
        "sunrise": "Sunrise",
        "sunset": "Sunset",
        "samvatsara": "Samvatsara",
        "masa": "Masa (Month)",
        "paksha": "Paksha",
        "tithi": "Tithi",
        "vara": "Vara (Weekday)",
        "nakshatra": "Nakshatra",
        "yoga": "Yoga",
        "karana": "Karana (Index)",
        "pada": "Pada"
    },
    "KN": {
        "title": "ಹಿಂದೂ ಪಂಚಾಂಗ ವರದಿ",
        "input_dt": "ನಿಗದಿತ ದಿನಾಂಕ/ಸಮಯ",
        "location": "ಸ್ಥಳ",
        "sunrise": "ಸೂರ್ಯೋದಯ",
        "sunset": "ಸೂರ್ಯಾಸ್ತ",
        "samvatsara": "ಸಂವತ್ಸರ",
        "masa": "ಮಾಸ",
        "paksha": "ಪಕ್ಷ",
        "tithi": "ತಿಥಿ",
        "vara": "ವಾರ",
        "nakshatra": "ನಕ್ಷತ್ರ",
        "yoga": "ಯೋಗ",
        "karana": "ಕರಣ (ಸೂಚ್ಯಂಕ)",
        "pada": "ಪಾದ"
    },
    "SA": {
        "title": "हिन्दू पञ्चाङ्ग विवरणम्",
        "input_dt": "दत्त समयः",
        "location": "स्थानम्",
        "sunrise": "सूर्योदयः",
        "sunset": "सूर्यास्तम्",
        "samvatsara": "संवत्सरः",
        "masa": "मासः",
        "paksha": "पक्षः",
        "tithi": "तिथिः",
        "vara": "वासरः",
        "nakshatra": "नक्षत्रम्",
        "yoga": "योगः",
        "karana": "करणम् (सूच्यङ्कः)",
        "pada": "पादः"
    }
}
